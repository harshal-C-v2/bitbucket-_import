exports.checkPermissions = (req, res, next) => {};
